<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('storage_objects', function (Blueprint $table) {
            $table->id();
            $table->string('provider');
            $table->string('uri', 2048);
            $table->string('mime_type')->nullable();
            $table->unsignedBigInteger('size_bytes')->nullable();
            $table->string('checksum')->nullable();
            $table->timestamps();
        });

        Schema::create('media_assets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('storage_object_id')->constrained('storage_objects')->onDelete('cascade');
            $table->unsignedInteger('duration_seconds')->nullable();
            $table->unsignedInteger('width')->nullable();
            $table->unsignedInteger('height')->nullable();
            $table->timestamps();
        });

        Schema::create('media_renditions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('media_asset_id')->constrained('media_assets')->onDelete('cascade');
            $table->string('codec')->nullable();
            $table->unsignedInteger('bitrate')->nullable();
            $table->unsignedInteger('width')->nullable();
            $table->unsignedInteger('height')->nullable();
            $table->string('uri', 2048);
            $table->timestamps();
        });

        Schema::create('video_media', function (Blueprint $table) {
            $table->string('video_id')->primary();
            $table->foreignId('media_asset_id')->nullable()->constrained('media_assets')->nullOnDelete();
            $table->string('playback_policy')->nullable();
            $table->timestamps();

            $table->foreign('video_id')->references('id')->on('videos')->onDelete('cascade');
        });

        Schema::create('captions', function (Blueprint $table) {
            $table->id();
            $table->string('video_id');
            $table->string('locale', 32);
            $table->string('format', 16);
            $table->foreignId('storage_object_id')->constrained('storage_objects')->onDelete('cascade');
            $table->timestamps();

            $table->unique(['video_id', 'locale', 'format']);
            $table->foreign('video_id')->references('id')->on('videos')->onDelete('cascade');
        });

        Schema::create('transcripts', function (Blueprint $table) {
            $table->id();
            $table->string('video_id');
            $table->string('locale', 32);
            $table->foreignId('storage_object_id')->nullable()->constrained('storage_objects')->nullOnDelete();
            $table->timestamps();

            $table->unique(['video_id', 'locale']);
            $table->foreign('video_id')->references('id')->on('videos')->onDelete('cascade');
        });

        Schema::create('transcript_segments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('transcript_id')->constrained('transcripts')->onDelete('cascade');
            $table->unsignedInteger('start_ms');
            $table->unsignedInteger('end_ms');
            $table->text('text');
            $table->timestamps();
        });

        Schema::create('exercise_files', function (Blueprint $table) {
            $table->id();
            $table->string('course_id');
            $table->string('title');
            $table->foreignId('storage_object_id')->constrained('storage_objects')->onDelete('cascade');
            $table->string('checksum')->nullable();
            $table->unsignedBigInteger('size_bytes')->nullable();
            $table->timestamps();

            $table->foreign('course_id')->references('id')->on('courses')->onDelete('cascade');
        });

        Schema::create('auth_identities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('provider', 32);
            $table->string('provider_user_id', 255);
            $table->timestamps();

            $table->unique(['provider', 'provider_user_id']);
        });

        Schema::create('organizations', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('status', 32)->default('active');
            $table->timestamps();
        });

        Schema::create('organization_domains', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained('organizations')->onDelete('cascade');
            $table->string('domain');
            $table->timestamp('verified_at')->nullable();
            $table->timestamps();

            $table->unique(['organization_id', 'domain']);
        });

        Schema::create('organization_members', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained('organizations')->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('status', 32)->default('active');
            $table->timestamp('joined_at')->nullable();
            $table->timestamps();

            $table->unique(['organization_id', 'user_id']);
        });

        Schema::create('organization_teams', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained('organizations')->onDelete('cascade');
            $table->string('name');
            $table->timestamps();

            $table->unique(['organization_id', 'name']);
        });

        Schema::create('organization_team_members', function (Blueprint $table) {
            $table->foreignId('organization_team_id')->constrained('organization_teams')->onDelete('cascade');
            $table->foreignId('organization_member_id')->constrained('organization_members')->onDelete('cascade');
            $table->timestamps();

            $table->primary(['organization_team_id', 'organization_member_id']);
        });

        Schema::create('org_sso_configs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained('organizations')->onDelete('cascade');
            $table->string('sso_type', 64);
            $table->json('metadata_json')->nullable();
            $table->boolean('enabled')->default(true);
            $table->timestamps();
        });

        Schema::create('libraries', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('library_code', 64)->unique();
            $table->char('country_code', 2)->nullable();
            $table->string('status', 32)->default('active');
            $table->timestamps();
        });

        Schema::create('library_branches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('library_id')->constrained('libraries')->onDelete('cascade');
            $table->string('name');
            $table->json('address_json')->nullable();
            $table->timestamps();
        });

        Schema::create('library_patrons', function (Blueprint $table) {
            $table->id();
            $table->foreignId('library_id')->constrained('libraries')->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('patron_external_id', 128)->nullable();
            $table->timestamps();

            $table->unique(['library_id', 'user_id']);
        });

        Schema::create('library_cards', function (Blueprint $table) {
            $table->id();
            $table->foreignId('library_patron_id')->constrained('library_patrons')->onDelete('cascade');
            $table->string('card_number_hash', 64);
            $table->string('status', 32)->default('active');
            $table->timestamps();

            $table->unique(['library_patron_id', 'card_number_hash']);
        });

        Schema::create('entitlements', function (Blueprint $table) {
            $table->id();
            $table->string('resource_type', 32);
            $table->string('resource_id', 64);
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->timestamps();

            $table->index(['resource_type', 'resource_id']);
        });

        Schema::create('entitlement_rules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('entitlement_id')->constrained('entitlements')->onDelete('cascade');
            $table->string('rule_type', 64);
            $table->json('rule_json');
            $table->timestamps();
        });

        Schema::create('user_entitlements', function (Blueprint $table) {
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('entitlement_id')->constrained('entitlements')->onDelete('cascade');
            $table->timestamps();
            $table->primary(['user_id', 'entitlement_id']);
        });

        Schema::create('org_entitlements', function (Blueprint $table) {
            $table->foreignId('organization_id')->constrained('organizations')->onDelete('cascade');
            $table->foreignId('entitlement_id')->constrained('entitlements')->onDelete('cascade');
            $table->timestamps();
            $table->primary(['organization_id', 'entitlement_id']);
        });

        Schema::create('library_entitlements', function (Blueprint $table) {
            $table->foreignId('library_id')->constrained('libraries')->onDelete('cascade');
            $table->foreignId('entitlement_id')->constrained('entitlements')->onDelete('cascade');
            $table->timestamps();
            $table->primary(['library_id', 'entitlement_id']);
        });

        Schema::create('seat_pools', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained('organizations')->onDelete('cascade');
            $table->string('name');
            $table->unsignedInteger('seat_count')->default(0);
            $table->timestamps();

            $table->unique(['organization_id', 'name']);
        });

        Schema::create('seat_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('seat_pool_id')->constrained('seat_pools')->onDelete('cascade');
            $table->foreignId('organization_member_id')->constrained('organization_members')->onDelete('cascade');
            $table->string('status', 32)->default('active');
            $table->timestamp('assigned_at')->nullable();
            $table->timestamp('revoked_at')->nullable();
            $table->timestamps();

            $table->unique(['seat_pool_id', 'organization_member_id']);
        });

        Schema::create('bookmarks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('course_id');
            $table->string('video_id');
            $table->unsignedInteger('position_seconds')->default(0);
            $table->timestamps();

            $table->foreign('course_id')->references('id')->on('courses')->onDelete('cascade');
            $table->foreign('video_id')->references('id')->on('videos')->onDelete('cascade');
        });

        Schema::create('notes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('course_id');
            $table->string('video_id')->nullable();
            $table->unsignedInteger('position_seconds')->default(0);
            $table->longText('note_text');
            $table->timestamps();

            $table->foreign('course_id')->references('id')->on('courses')->onDelete('cascade');
            $table->foreign('video_id')->references('id')->on('videos')->nullOnDelete();
        });

        Schema::create('discussion_threads', function (Blueprint $table) {
            $table->id();
            $table->string('course_id');
            $table->string('video_id')->nullable();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('title');
            $table->string('status', 32)->default('open');
            $table->timestamps();

            $table->foreign('course_id')->references('id')->on('courses')->onDelete('cascade');
            $table->foreign('video_id')->references('id')->on('videos')->nullOnDelete();
        });

        Schema::create('discussion_posts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('discussion_thread_id')->constrained('discussion_threads')->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->longText('body');
            $table->string('status', 32)->default('published');
            $table->timestamps();
        });

        Schema::create('discussion_reactions', function (Blueprint $table) {
            $table->foreignId('discussion_post_id')->constrained('discussion_posts')->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('reaction', 32);
            $table->timestamps();
            $table->primary(['discussion_post_id', 'user_id', 'reaction']);
        });

        Schema::create('quizzes', function (Blueprint $table) {
            $table->id();
            $table->string('video_id');
            $table->string('title');
            $table->unsignedInteger('passing_score_percent')->default(70);
            $table->unsignedInteger('time_limit_seconds')->nullable();
            $table->timestamps();

            $table->unique(['video_id']);
            $table->foreign('video_id')->references('id')->on('videos')->onDelete('cascade');
        });

        Schema::create('quiz_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('quiz_id')->constrained('quizzes')->onDelete('cascade');
            $table->string('question_type', 32)->default('single_choice');
            $table->longText('question_text');
            $table->unsignedInteger('position');
            $table->unsignedInteger('points')->default(1);
            $table->timestamps();

            $table->unique(['quiz_id', 'position']);
        });

        Schema::create('quiz_options', function (Blueprint $table) {
            $table->id();
            $table->foreignId('quiz_question_id')->constrained('quiz_questions')->onDelete('cascade');
            $table->longText('option_text');
            $table->boolean('is_correct')->default(false);
            $table->unsignedInteger('position');
            $table->timestamps();

            $table->unique(['quiz_question_id', 'position']);
        });

        Schema::create('quiz_attempts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('quiz_id')->constrained('quizzes')->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->timestamp('started_at')->useCurrent();
            $table->timestamp('completed_at')->nullable();
            $table->unsignedInteger('score_percent')->nullable();
            $table->string('status', 32)->default('in_progress');
            $table->timestamps();

            $table->index(['quiz_id', 'user_id', 'started_at']);
        });

        Schema::create('quiz_answers', function (Blueprint $table) {
            $table->foreignId('quiz_attempt_id')->constrained('quiz_attempts')->onDelete('cascade');
            $table->foreignId('quiz_question_id')->constrained('quiz_questions')->onDelete('cascade');
            $table->foreignId('quiz_option_id')->constrained('quiz_options')->onDelete('cascade');
            $table->timestamps();
            $table->primary(['quiz_attempt_id', 'quiz_question_id', 'quiz_option_id']);
        });

        Schema::create('certificate_templates', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->longText('template_html');
            $table->timestamps();
        });

        Schema::create('certificates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('enrollment_id')->constrained('enrollments')->onDelete('cascade');
            $table->foreignId('certificate_template_id')->nullable()->constrained('certificate_templates')->nullOnDelete();
            $table->string('certificate_code', 64)->unique();
            $table->timestamp('issued_at')->useCurrent();
            $table->timestamps();

            $table->unique(['enrollment_id']);
        });

        Schema::create('credential_shares', function (Blueprint $table) {
            $table->id();
            $table->foreignId('certificate_id')->constrained('certificates')->onDelete('cascade');
            $table->string('provider', 64);
            $table->string('provider_ref')->nullable();
            $table->timestamps();
        });

        Schema::create('plans', function (Blueprint $table) {
            $table->id();
            $table->string('code', 64)->unique();
            $table->string('name');
            $table->string('billing_period', 16);
            $table->unsignedInteger('price_cents');
            $table->char('currency', 3)->default('USD');
            $table->timestamps();
        });

        Schema::create('plan_features', function (Blueprint $table) {
            $table->foreignId('plan_id')->constrained('plans')->onDelete('cascade');
            $table->string('feature_code', 64);
            $table->string('feature_value')->nullable();
            $table->timestamps();
            $table->primary(['plan_id', 'feature_code']);
        });

        Schema::create('subscriptions', function (Blueprint $table) {
            $table->id();
            $table->string('subject_type', 32);
            $table->unsignedBigInteger('subject_id');
            $table->foreignId('plan_id')->constrained('plans')->onDelete('restrict');
            $table->string('status', 32)->default('trialing');
            $table->timestamp('trial_ends_at')->nullable();
            $table->timestamp('current_period_start');
            $table->timestamp('current_period_end');
            $table->boolean('cancel_at_period_end')->default(false);
            $table->timestamps();

            $table->index(['subject_type', 'subject_id']);
        });

        Schema::create('coupons', function (Blueprint $table) {
            $table->id();
            $table->string('code', 64)->unique();
            $table->unsignedInteger('percent_off')->nullable();
            $table->unsignedInteger('amount_off_cents')->nullable();
            $table->char('currency', 3)->nullable();
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->unsignedInteger('max_redemptions')->nullable();
            $table->timestamps();
        });

        Schema::create('subscription_coupons', function (Blueprint $table) {
            $table->foreignId('subscription_id')->constrained('subscriptions')->onDelete('cascade');
            $table->foreignId('coupon_id')->constrained('coupons')->onDelete('restrict');
            $table->timestamp('applied_at')->useCurrent();
            $table->timestamps();
            $table->primary(['subscription_id', 'coupon_id']);
        });

        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subscription_id')->constrained('subscriptions')->onDelete('cascade');
            $table->unsignedInteger('amount_cents');
            $table->char('currency', 3)->default('USD');
            $table->string('status', 32)->default('open');
            $table->timestamp('issued_at')->useCurrent();
            $table->timestamp('due_at')->nullable();
            $table->timestamps();
        });

        Schema::create('invoice_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained('invoices')->onDelete('cascade');
            $table->string('description');
            $table->unsignedInteger('amount_cents');
            $table->unsignedInteger('quantity')->default(1);
            $table->timestamps();
        });

        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained('invoices')->onDelete('cascade');
            $table->string('provider', 64);
            $table->string('provider_payment_id')->nullable();
            $table->unsignedInteger('amount_cents');
            $table->char('currency', 3)->default('USD');
            $table->string('status', 32)->default('pending');
            $table->timestamps();
        });

        Schema::create('refunds', function (Blueprint $table) {
            $table->id();
            $table->foreignId('payment_id')->constrained('payments')->onDelete('cascade');
            $table->unsignedInteger('amount_cents');
            $table->string('status', 32)->default('pending');
            $table->timestamps();
        });

        Schema::create('devices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('device_type', 64)->nullable();
            $table->string('device_fingerprint_hash', 128);
            $table->timestamps();

            $table->unique(['user_id', 'device_fingerprint_hash']);
        });

        Schema::create('watch_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('video_id');
            $table->foreignId('device_id')->nullable()->constrained('devices')->nullOnDelete();
            $table->timestamp('started_at')->useCurrent();
            $table->timestamp('ended_at')->nullable();
            $table->unsignedInteger('total_watch_seconds')->default(0);
            $table->timestamps();

            $table->foreign('video_id')->references('id')->on('videos')->onDelete('cascade');
            $table->index(['user_id', 'started_at']);
            $table->index(['video_id', 'started_at']);
        });

        Schema::create('playback_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('video_id');
            $table->foreignId('watch_session_id')->nullable()->constrained('watch_sessions')->nullOnDelete();
            $table->string('event_type', 64);
            $table->unsignedInteger('position_seconds')->default(0);
            $table->timestamp('event_at')->useCurrent();
            $table->timestamps();

            $table->foreign('video_id')->references('id')->on('videos')->onDelete('cascade');
            $table->index(['user_id', 'event_at']);
            $table->index(['video_id', 'event_at']);
        });

        Schema::create('search_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('query_text', 500);
            $table->json('filters_json')->nullable();
            $table->timestamp('searched_at')->useCurrent();
            $table->timestamps();

            $table->index(['user_id', 'searched_at']);
        });

        Schema::create('content_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('event_name', 128);
            $table->string('entity_type', 64);
            $table->string('entity_id', 64);
            $table->json('meta_json')->nullable();
            $table->timestamp('event_at')->useCurrent();
            $table->timestamps();

            $table->index(['user_id', 'event_at']);
            $table->index(['entity_type', 'entity_id', 'event_at']);
        });

        Schema::create('trending_items', function (Blueprint $table) {
            $table->id();
            $table->string('item_type', 64);
            $table->string('item_id', 64);
            $table->string('window', 32);
            $table->decimal('score', 12, 6)->default(0);
            $table->timestamp('computed_at')->useCurrent();
            $table->timestamps();

            $table->index(['item_type', 'window', 'computed_at']);
        });

        Schema::create('recommendation_models', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('version', 64);
            $table->timestamps();

            $table->unique(['name', 'version']);
        });

        Schema::create('recommendations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('recommendation_model_id')->constrained('recommendation_models')->onDelete('restrict');
            $table->timestamps();

            $table->index(['user_id', 'created_at']);
        });

        Schema::create('recommendation_items', function (Blueprint $table) {
            $table->foreignId('recommendation_id')->constrained('recommendations')->onDelete('cascade');
            $table->string('item_type', 64);
            $table->string('item_id', 64);
            $table->decimal('score', 12, 6)->default(0);
            $table->unsignedInteger('position')->default(0);
            $table->timestamps();

            $table->primary(['recommendation_id', 'item_type', 'item_id']);
            $table->unique(['recommendation_id', 'position']);
        });

        Schema::create('user_feed_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('item_type', 64);
            $table->string('item_id', 64);
            $table->decimal('rank_score', 12, 6)->default(0);
            $table->timestamp('seen_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_feed_items');
        Schema::dropIfExists('recommendation_items');
        Schema::dropIfExists('recommendations');
        Schema::dropIfExists('recommendation_models');
        Schema::dropIfExists('trending_items');
        Schema::dropIfExists('content_events');
        Schema::dropIfExists('search_events');
        Schema::dropIfExists('playback_events');
        Schema::dropIfExists('watch_sessions');
        Schema::dropIfExists('devices');
        Schema::dropIfExists('refunds');
        Schema::dropIfExists('payments');
        Schema::dropIfExists('invoice_items');
        Schema::dropIfExists('invoices');
        Schema::dropIfExists('subscription_coupons');
        Schema::dropIfExists('coupons');
        Schema::dropIfExists('subscriptions');
        Schema::dropIfExists('plan_features');
        Schema::dropIfExists('plans');
        Schema::dropIfExists('credential_shares');
        Schema::dropIfExists('certificates');
        Schema::dropIfExists('certificate_templates');
        Schema::dropIfExists('quiz_answers');
        Schema::dropIfExists('quiz_attempts');
        Schema::dropIfExists('quiz_options');
        Schema::dropIfExists('quiz_questions');
        Schema::dropIfExists('quizzes');
        Schema::dropIfExists('discussion_reactions');
        Schema::dropIfExists('discussion_posts');
        Schema::dropIfExists('discussion_threads');
        Schema::dropIfExists('notes');
        Schema::dropIfExists('bookmarks');
        Schema::dropIfExists('seat_assignments');
        Schema::dropIfExists('seat_pools');
        Schema::dropIfExists('library_entitlements');
        Schema::dropIfExists('org_entitlements');
        Schema::dropIfExists('user_entitlements');
        Schema::dropIfExists('entitlement_rules');
        Schema::dropIfExists('entitlements');
        Schema::dropIfExists('library_cards');
        Schema::dropIfExists('library_patrons');
        Schema::dropIfExists('library_branches');
        Schema::dropIfExists('libraries');
        Schema::dropIfExists('org_sso_configs');
        Schema::dropIfExists('organization_team_members');
        Schema::dropIfExists('organization_teams');
        Schema::dropIfExists('organization_members');
        Schema::dropIfExists('organization_domains');
        Schema::dropIfExists('organizations');
        Schema::dropIfExists('auth_identities');
        Schema::dropIfExists('exercise_files');
        Schema::dropIfExists('transcript_segments');
        Schema::dropIfExists('transcripts');
        Schema::dropIfExists('captions');
        Schema::dropIfExists('video_media');
        Schema::dropIfExists('media_renditions');
        Schema::dropIfExists('media_assets');
        Schema::dropIfExists('storage_objects');
    }
};

