<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    private function normalizeMysqlIdentifier(?string $value, string $default): string
    {
        $value = (string) $value;
        return preg_match('/^[0-9A-Za-z_]+$/', $value) ? $value : $default;
    }

    private function mysqlCollation(): string
    {
        return $this->normalizeMysqlIdentifier(config('database.connections.mysql.collation'), 'utf8mb4_unicode_ci');
    }

    private function mysqlCharset(): string
    {
        return $this->normalizeMysqlIdentifier(config('database.connections.mysql.charset'), 'utf8mb4');
    }

    public function up(): void
    {
        $charset = $this->mysqlCharset();
        $collation = $this->mysqlCollation();

        // ── TRIGGER 1: Auto-update enrollment last_activity ─────────────────
        // Ketika video_progress diupdate, update enrolled_at timestamp
        DB::unprepared(str_replace(['__CHARSET__', '__COLLATION__'], [$charset, $collation], '
            DROP TRIGGER IF EXISTS trg_enrollment_activity_insert;
            CREATE TRIGGER trg_enrollment_activity_insert
            AFTER INSERT ON video_progress
            FOR EACH ROW
            BEGIN
                UPDATE enrollments
                SET updated_at = NOW()
                WHERE user_id = NEW.user_id
                  AND course_id = (
                      SELECT course_id FROM videos
                      WHERE id COLLATE __COLLATION__ = NEW.video_id COLLATE __COLLATION__
                      LIMIT 1
                  );
            END
        '));

        // ── TRIGGER 2: Auto-complete enrollment ────────────────────────────
        // Ketika semua video dalam course sudah completed
        DB::unprepared(str_replace(['__CHARSET__', '__COLLATION__'], [$charset, $collation], '
            DROP TRIGGER IF EXISTS trg_check_enrollment_complete;
            CREATE TRIGGER trg_check_enrollment_complete
            AFTER UPDATE ON video_progress
            FOR EACH ROW
            BEGIN
                DECLARE v_course_id VARCHAR(64) CHARACTER SET __CHARSET__ COLLATE __COLLATION__;
                DECLARE total_videos INT;
                DECLARE completed_videos INT;

                IF NEW.is_completed = 1 AND (OLD.is_completed = 0 OR OLD.is_completed IS NULL) THEN
                    SELECT course_id INTO v_course_id
                    FROM videos
                    WHERE id COLLATE __COLLATION__ = NEW.video_id COLLATE __COLLATION__
                    LIMIT 1;

                    SELECT COUNT(*) INTO total_videos
                    FROM videos WHERE course_id = v_course_id;

                    SELECT COUNT(*) INTO completed_videos
                    FROM video_progress vp
                    JOIN videos v ON vp.video_id COLLATE __COLLATION__ = v.id COLLATE __COLLATION__
                    WHERE v.course_id = v_course_id
                      AND vp.user_id = NEW.user_id
                      AND vp.is_completed = 1;

                    IF completed_videos >= total_videos AND total_videos > 0 THEN
                        UPDATE enrollments
                        SET status = \'completed\',
                            completed_at = NOW(),
                            updated_at = NOW()
                        WHERE user_id = NEW.user_id
                          AND course_id = v_course_id
                          AND status != \'completed\';
                    END IF;
                END IF;
            END
        '));

        // ── TRIGGER 3: Auto-generate certificate ───────────────────────────
        // Ketika enrollment status berubah ke 'completed'
        DB::unprepared('
            DROP TRIGGER IF EXISTS trg_generate_certificate;
            CREATE TRIGGER trg_generate_certificate
            AFTER UPDATE ON enrollments
            FOR EACH ROW
            BEGIN
                IF NEW.status = \'completed\' AND OLD.status != \'completed\' THEN
                    INSERT IGNORE INTO certificates (enrollment_id, certificate_code, issued_at, created_at, updated_at)
                    VALUES (
                        NEW.id,
                        CONCAT(\'CERT-\', UPPER(SUBSTRING(MD5(CONCAT(NEW.id, NOW())), 1, 12))),
                        NOW(), NOW(), NOW()
                    );
                END IF;
            END
        ');

        // ── TRIGGER 4: Update course rating average ────────────────────────
        // Ketika review baru ditambahkan di course_reviews
        DB::unprepared('
            DROP TRIGGER IF EXISTS trg_update_course_rating_insert;
            CREATE TRIGGER trg_update_course_rating_insert
            AFTER INSERT ON course_reviews
            FOR EACH ROW
            BEGIN
                UPDATE courses
                SET rating = (
                        SELECT AVG(rating) FROM course_reviews
                        WHERE course_id = NEW.course_id AND status = \'published\'
                    ),
                    rating_count = (
                        SELECT COUNT(*) FROM course_reviews
                        WHERE course_id = NEW.course_id AND status = \'published\'
                    ),
                    updated_at = NOW()
                WHERE id = NEW.course_id;
            END
        ');

        DB::unprepared('
            DROP TRIGGER IF EXISTS trg_update_course_rating_update;
            CREATE TRIGGER trg_update_course_rating_update
            AFTER UPDATE ON course_reviews
            FOR EACH ROW
            BEGIN
                UPDATE courses
                SET rating = (
                        SELECT AVG(rating) FROM course_reviews
                        WHERE course_id = NEW.course_id AND status = \'published\'
                    ),
                    rating_count = (
                        SELECT COUNT(*) FROM course_reviews
                        WHERE course_id = NEW.course_id AND status = \'published\'
                    ),
                    updated_at = NOW()
                WHERE id = NEW.course_id;
            END
        ');

        DB::unprepared('
            DROP TRIGGER IF EXISTS trg_update_course_rating_delete;
            CREATE TRIGGER trg_update_course_rating_delete
            AFTER DELETE ON course_reviews
            FOR EACH ROW
            BEGIN
                UPDATE courses
                SET rating = (
                        SELECT AVG(rating) FROM course_reviews
                        WHERE course_id = OLD.course_id AND status = \'published\'
                    ),
                    rating_count = (
                        SELECT COUNT(*) FROM course_reviews
                        WHERE course_id = OLD.course_id AND status = \'published\'
                    ),
                    updated_at = NOW()
                WHERE id = OLD.course_id;
            END
        ');

        // ── TRIGGER 5: Calculate quiz score on completion ──────────────────
        DB::unprepared('
            DROP TRIGGER IF EXISTS trg_calculate_quiz_score;
            CREATE TRIGGER trg_calculate_quiz_score
            BEFORE UPDATE ON quiz_attempts
            FOR EACH ROW
            BEGIN
                DECLARE total_points INT DEFAULT 0;
                DECLARE earned_points INT DEFAULT 0;

                IF NEW.status = \'completed\' AND OLD.status != \'completed\' THEN
                    SELECT COALESCE(SUM(qq.points), 0) INTO total_points
                    FROM quiz_questions qq
                    WHERE qq.quiz_id = NEW.quiz_id;

                    SELECT COALESCE(SUM(qq.points), 0) INTO earned_points
                    FROM quiz_answers qa
                    JOIN quiz_options qo ON qa.quiz_option_id = qo.id
                    JOIN quiz_questions qq ON qa.quiz_question_id = qq.id
                    WHERE qa.quiz_attempt_id = NEW.id AND qo.is_correct = 1;

                    IF total_points > 0 THEN
                        SET NEW.score_percent = ROUND((earned_points / total_points) * 100);
                    ELSE
                        SET NEW.score_percent = 0;
                    END IF;

                    SET NEW.completed_at = NOW();
                END IF;
            END
        ');

        // ── TRIGGER 6: Auto-start enrollment on first progress ────────────
        DB::unprepared(str_replace(['__CHARSET__', '__COLLATION__'], [$charset, $collation], '
            DROP TRIGGER IF EXISTS trg_start_enrollment;
            CREATE TRIGGER trg_start_enrollment
            AFTER INSERT ON video_progress
            FOR EACH ROW
            BEGIN
                DECLARE v_course_id VARCHAR(64) CHARACTER SET __CHARSET__ COLLATE __COLLATION__;

                SELECT course_id INTO v_course_id
                FROM videos
                WHERE id COLLATE __COLLATION__ = NEW.video_id COLLATE __COLLATION__
                LIMIT 1;

                UPDATE enrollments
                SET status = \'in_progress\',
                    enrolled_at = COALESCE(enrolled_at, NOW()),
                    updated_at = NOW()
                WHERE user_id = NEW.user_id
                  AND course_id = v_course_id
                  AND status = \'saved\';
            END
        '));

        // ── TRIGGER 7: Auto-queue moderation on abuse report ──────────────
        DB::unprepared('
            DROP TRIGGER IF EXISTS trg_auto_queue_moderation;
            CREATE TRIGGER trg_auto_queue_moderation
            AFTER INSERT ON abuse_reports
            FOR EACH ROW
            BEGIN
                INSERT INTO content_moderation_queue
                    (entity_type, entity_id, reason, status, created_at, updated_at)
                VALUES
                    (NEW.entity_type, NEW.entity_id, NEW.reason, \'pending\', NOW(), NOW())
                ON DUPLICATE KEY UPDATE status = \'pending\', updated_at = NOW();
            END
        ');

        // ── TRIGGER 8: Update chapter video count ─────────────────────────
        DB::unprepared('
            DROP TRIGGER IF EXISTS trg_update_chapter_video_count_insert;
            CREATE TRIGGER trg_update_chapter_video_count_insert
            AFTER INSERT ON videos
            FOR EACH ROW
            BEGIN
                IF NEW.chapter_id IS NOT NULL THEN
                    UPDATE chapters
                    SET jumlah_video = (
                        SELECT COUNT(*) FROM videos WHERE chapter_id = NEW.chapter_id
                    ),
                    updated_at = NOW()
                    WHERE id = NEW.chapter_id;
                END IF;
            END
        ');

        DB::unprepared('
            DROP TRIGGER IF EXISTS trg_update_chapter_video_count_delete;
            CREATE TRIGGER trg_update_chapter_video_count_delete
            AFTER DELETE ON videos
            FOR EACH ROW
            BEGIN
                IF OLD.chapter_id IS NOT NULL THEN
                    UPDATE chapters
                    SET jumlah_video = (
                        SELECT COUNT(*) FROM videos WHERE chapter_id = OLD.chapter_id
                    ),
                    updated_at = NOW()
                    WHERE id = OLD.chapter_id;
                END IF;
            END
        ');
    }

    public function down(): void
    {
        $triggers = [
            'trg_enrollment_activity_insert',
            'trg_check_enrollment_complete',
            'trg_generate_certificate',
            'trg_update_course_rating_insert',
            'trg_update_course_rating_update',
            'trg_update_course_rating_delete',
            'trg_calculate_quiz_score',
            'trg_start_enrollment',
            'trg_auto_queue_moderation',
            'trg_update_chapter_video_count_insert',
            'trg_update_chapter_video_count_delete',
        ];

        foreach ($triggers as $trigger) {
            DB::unprepared("DROP TRIGGER IF EXISTS {$trigger}");
        }
    }
};
