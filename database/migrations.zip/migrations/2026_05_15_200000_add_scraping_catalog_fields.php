<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('courses', function (Blueprint $table) {
            $table->string('scraped_level')->nullable()->after('level');
            $table->date('release_date')->nullable()->after('scraped_level');
            $table->unsignedInteger('rating_count')->nullable()->after('rating');
            $table->string('source_url')->nullable()->after('rating_count');
        });

        Schema::table('videos', function (Blueprint $table) {
            $table->string('tipe')->nullable()->after('is_preview');
        });

        Schema::create('instructors', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->string('name');
            $table->string('slug');
            $table->string('info')->nullable();
            $table->text('bio')->nullable();
            $table->string('link')->nullable();
            $table->timestamps();

            $table->unique(['name', 'slug']);
        });

        Schema::create('course_instructor', function (Blueprint $table) {
            $table->string('course_id');
            $table->string('instructor_id');
            $table->primary(['course_id', 'instructor_id']);

            $table->foreign('course_id')->references('id')->on('courses')->onDelete('cascade');
            $table->foreign('instructor_id')->references('id')->on('instructors')->onDelete('cascade');
        });

        Schema::create('course_includes', function (Blueprint $table) {
            $table->id();
            $table->string('course_id');
            $table->string('item');
            $table->timestamps();

            $table->unique(['course_id', 'item']);
            $table->foreign('course_id')->references('id')->on('courses')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('course_includes');
        Schema::dropIfExists('course_instructor');
        Schema::dropIfExists('instructors');

        Schema::table('videos', function (Blueprint $table) {
            $table->dropColumn('tipe');
        });

        Schema::table('courses', function (Blueprint $table) {
            $table->dropColumn([
                'scraped_level',
                'release_date',
                'rating_count',
                'source_url',
            ]);
        });
    }
};
