<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // ── COURSE REVIEWS & VOTES ──────────────────────────────────────────
        Schema::create('course_reviews', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('course_id');
            $table->unsignedTinyInteger('rating'); // 1-5
            $table->longText('review_text')->nullable();
            $table->string('status', 32)->default('published'); // published, hidden, flagged
            $table->timestamps();

            $table->unique(['user_id', 'course_id']);
            $table->foreign('course_id')->references('id')->on('courses')->onDelete('cascade');
        });

        Schema::create('review_votes', function (Blueprint $table) {
            $table->foreignId('course_review_id')->constrained('course_reviews')->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('vote', 16); // helpful, not_helpful
            $table->timestamps();
            $table->primary(['course_review_id', 'user_id']);
        });

        // ── NOTIFICATIONS ───────────────────────────────────────────────────
        Schema::create('notification_templates', function (Blueprint $table) {
            $table->id();
            $table->string('channel', 32); // email, push, in_app
            $table->string('code', 64);
            $table->json('template_json');
            $table->timestamps();

            $table->unique(['channel', 'code']);
        });

        Schema::create('notifications', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('notification_template_id')->nullable()->constrained('notification_templates')->nullOnDelete();
            $table->json('payload_json')->nullable();
            $table->string('status', 32)->default('unread'); // unread, read, dismissed
            $table->timestamp('read_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'status']);
        });

        Schema::create('email_outbox', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('subject');
            $table->longText('body');
            $table->string('status', 32)->default('queued'); // queued, sent, failed
            $table->string('provider_message_id')->nullable();
            $table->timestamps();
        });

        Schema::create('push_tokens', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('platform', 32); // ios, android, web
            $table->string('token');
            $table->timestamps();

            $table->unique(['platform', 'token']);
        });

        // ── AUDIT & MODERATION ──────────────────────────────────────────────
        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('action', 64);
            $table->string('entity_type', 64);
            $table->string('entity_id', 64);
            $table->json('diff_json')->nullable();
            $table->timestamps();

            $table->index(['entity_type', 'entity_id']);
            $table->index(['actor_user_id', 'created_at']);
        });

        Schema::create('content_moderation_queue', function (Blueprint $table) {
            $table->id();
            $table->string('entity_type', 64);
            $table->string('entity_id', 64);
            $table->string('reason');
            $table->string('status', 32)->default('pending'); // pending, approved, rejected
            $table->foreignId('reviewed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('reviewed_at')->nullable();
            $table->timestamps();

            $table->index(['status', 'created_at']);
        });

        Schema::create('abuse_reports', function (Blueprint $table) {
            $table->id();
            $table->foreignId('reporter_user_id')->constrained('users')->onDelete('cascade');
            $table->string('entity_type', 64);
            $table->string('entity_id', 64);
            $table->string('reason');
            $table->longText('details')->nullable();
            $table->string('status', 32)->default('open'); // open, investigating, resolved, dismissed
            $table->timestamps();
        });

        // ── COMPLIANCE (GDPR) ───────────────────────────────────────────────
        Schema::create('consents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('consent_type', 64); // marketing, analytics, cookies
            $table->boolean('granted')->default(false);
            $table->timestamps();

            $table->unique(['user_id', 'consent_type']);
        });

        Schema::create('data_requests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('request_type', 32); // export, deletion
            $table->string('status', 32)->default('pending'); // pending, processing, completed
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('data_requests');
        Schema::dropIfExists('consents');
        Schema::dropIfExists('abuse_reports');
        Schema::dropIfExists('content_moderation_queue');
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('push_tokens');
        Schema::dropIfExists('email_outbox');
        Schema::dropIfExists('notifications');
        Schema::dropIfExists('notification_templates');
        Schema::dropIfExists('review_votes');
        Schema::dropIfExists('course_reviews');
    }
};
