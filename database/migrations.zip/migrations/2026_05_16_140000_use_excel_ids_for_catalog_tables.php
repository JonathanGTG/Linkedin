<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private array $foreignKeys = [
        ['courses', 'courses_category_id_foreign'],
        ['chapters', 'chapters_course_id_foreign'],
        ['videos', 'videos_course_id_foreign'],
        ['videos', 'videos_chapter_id_foreign'],
        ['enrollments', 'enrollments_course_id_foreign'],
        ['video_progress', 'video_progress_video_id_foreign'],
        ['course_skill', 'course_skill_course_id_foreign'],
        ['course_skill', 'course_skill_skill_id_foreign'],
        ['hands_on_labs', 'hands_on_labs_course_id_foreign'],
        ['learning_plan_courses', 'learning_plan_courses_course_id_foreign'],
        ['course_instructor', 'course_instructor_course_id_foreign'],
        ['course_instructor', 'course_instructor_instructor_id_foreign'],
        ['course_includes', 'course_includes_course_id_foreign'],
        ['course_ratings', 'course_ratings_course_id_foreign'],
    ];

    public function up(): void
    {
        if (! Schema::hasColumn('courses', 'external_id')) {
            return;
        }

        $this->assertReady();

        DB::statement('SET FOREIGN_KEY_CHECKS=0');

        foreach ($this->foreignKeys as [$table, $name]) {
            $this->dropForeignIfExists($table, $name);
        }

        $this->makeForeignColumnsString();
        $this->copyExcelIdsToForeignColumns();
        $this->makePrimaryKeysString();
        $this->copyExcelIdsToPrimaryKeys();
        $this->dropExternalIdColumns();
        $this->recreateForeignKeys();

        DB::statement('SET FOREIGN_KEY_CHECKS=1');
    }

    public function down(): void
    {
        throw new RuntimeException('Migrasi ini tidak bisa di-rollback otomatis karena primary key sudah diganti ke ID Excel.');
    }

    private function normalizeMysqlIdentifier(?string $value, string $default): string
    {
        $value = (string) $value;
        return preg_match('/^[0-9A-Za-z_]+$/', $value) ? $value : $default;
    }

    private function mysqlCharset(): string
    {
        return $this->normalizeMysqlIdentifier(config('database.connections.mysql.charset'), 'utf8mb4');
    }

    private function mysqlCollation(): string
    {
        return $this->normalizeMysqlIdentifier(config('database.connections.mysql.collation'), 'utf8mb4_unicode_ci');
    }

    private function varchar64(string $nullability): string
    {
        $charset = $this->mysqlCharset();
        $collation = $this->mysqlCollation();

        return "VARCHAR(64) CHARACTER SET {$charset} COLLATE {$collation} {$nullability}";
    }

    private function assertReady(): void
    {
        foreach (['categories', 'courses', 'chapters', 'videos', 'skills', 'instructors'] as $table) {
            $missing = DB::table($table)->whereNull('external_id')->orWhere('external_id', '')->count();
            if ($missing > 0) {
                throw new RuntimeException("Tabel {$table} masih punya {$missing} baris tanpa external_id.");
            }

            $duplicates = DB::table($table)
                ->select('external_id')
                ->groupBy('external_id')
                ->havingRaw('COUNT(*) > 1')
                ->count();

            if ($duplicates > 0) {
                throw new RuntimeException("Tabel {$table} punya external_id duplikat.");
            }
        }
    }

    private function makeForeignColumnsString(): void
    {
        $notNull = $this->varchar64('NOT NULL');
        $nullable = $this->varchar64('NULL');

        foreach ([
            'courses.category_id' => $notNull,
            'chapters.course_id' => $notNull,
            'videos.course_id' => $notNull,
            'videos.chapter_id' => $nullable,
            'enrollments.course_id' => $notNull,
            'course_ratings.course_id' => $notNull,
            'hands_on_labs.course_id' => $nullable,
            'learning_plan_courses.course_id' => $notNull,
            'course_skill.course_id' => $notNull,
            'course_skill.skill_id' => $notNull,
            'course_instructor.course_id' => $notNull,
            'course_instructor.instructor_id' => $notNull,
            'course_includes.course_id' => $notNull,
            'video_progress.video_id' => $notNull,
        ] as $column => $definition) {
            [$table, $name] = explode('.', $column);
            if (Schema::hasTable($table) && Schema::hasColumn($table, $name)) {
                DB::statement("ALTER TABLE `{$table}` MODIFY `{$name}` {$definition}");
            }
        }
    }

    private function copyExcelIdsToForeignColumns(): void
    {
        DB::statement('UPDATE `courses` c JOIN `categories` cat ON c.`category_id` = cat.`id` SET c.`category_id` = cat.`external_id`');
        DB::statement('UPDATE `chapters` ch JOIN `courses` c ON ch.`course_id` = c.`id` SET ch.`course_id` = c.`external_id`');
        DB::statement('UPDATE `videos` v JOIN `courses` c ON v.`course_id` = c.`id` SET v.`course_id` = c.`external_id`');
        DB::statement('UPDATE `videos` v JOIN `chapters` ch ON v.`chapter_id` = ch.`id` SET v.`chapter_id` = ch.`external_id` WHERE v.`chapter_id` IS NOT NULL');
        DB::statement('UPDATE `enrollments` e JOIN `courses` c ON e.`course_id` = c.`id` SET e.`course_id` = c.`external_id`');
        DB::statement('UPDATE `course_ratings` cr JOIN `courses` c ON cr.`course_id` = c.`id` SET cr.`course_id` = c.`external_id`');
        DB::statement('UPDATE `hands_on_labs` h JOIN `courses` c ON h.`course_id` = c.`id` SET h.`course_id` = c.`external_id` WHERE h.`course_id` IS NOT NULL');
        DB::statement('UPDATE `learning_plan_courses` lpc JOIN `courses` c ON lpc.`course_id` = c.`id` SET lpc.`course_id` = c.`external_id`');
        DB::statement('UPDATE `course_skill` cs JOIN `courses` c ON cs.`course_id` = c.`id` SET cs.`course_id` = c.`external_id`');
        DB::statement('UPDATE `course_skill` cs JOIN `skills` s ON cs.`skill_id` = s.`id` SET cs.`skill_id` = s.`external_id`');
        DB::statement('UPDATE `course_instructor` ci JOIN `courses` c ON ci.`course_id` = c.`id` SET ci.`course_id` = c.`external_id`');
        DB::statement('UPDATE `course_instructor` ci JOIN `instructors` i ON ci.`instructor_id` = i.`id` SET ci.`instructor_id` = i.`external_id`');
        DB::statement('UPDATE `course_includes` inc JOIN `courses` c ON inc.`course_id` = c.`id` SET inc.`course_id` = c.`external_id`');
        DB::statement('UPDATE `video_progress` vp JOIN `videos` v ON vp.`video_id` = v.`id` SET vp.`video_id` = v.`external_id`');
    }

    private function makePrimaryKeysString(): void
    {
        $notNull = $this->varchar64('NOT NULL');

        foreach (['categories', 'courses', 'chapters', 'videos', 'skills', 'instructors'] as $table) {
            DB::statement("ALTER TABLE `{$table}` MODIFY `id` {$notNull}");
            DB::statement("UPDATE `{$table}` SET `id` = CONCAT('__old__', `id`)");
        }
    }

    private function copyExcelIdsToPrimaryKeys(): void
    {
        foreach (['categories', 'courses', 'chapters', 'videos', 'skills', 'instructors'] as $table) {
            DB::statement("UPDATE `{$table}` SET `id` = `external_id`");
        }
    }

    private function dropExternalIdColumns(): void
    {
        foreach (['categories', 'courses', 'chapters', 'videos', 'skills', 'instructors'] as $table) {
            $this->dropUniqueForColumnIfExists($table, 'external_id');
            DB::statement("ALTER TABLE `{$table}` DROP COLUMN `external_id`");
        }
    }

    private function recreateForeignKeys(): void
    {
        DB::statement('ALTER TABLE `courses` ADD CONSTRAINT `courses_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `chapters` ADD CONSTRAINT `chapters_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `videos` ADD CONSTRAINT `videos_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `videos` ADD CONSTRAINT `videos_chapter_id_foreign` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `enrollments` ADD CONSTRAINT `enrollments_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `course_ratings` ADD CONSTRAINT `course_ratings_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `hands_on_labs` ADD CONSTRAINT `hands_on_labs_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE SET NULL');
        DB::statement('ALTER TABLE `learning_plan_courses` ADD CONSTRAINT `learning_plan_courses_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `course_skill` ADD CONSTRAINT `course_skill_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `course_skill` ADD CONSTRAINT `course_skill_skill_id_foreign` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `course_instructor` ADD CONSTRAINT `course_instructor_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `course_instructor` ADD CONSTRAINT `course_instructor_instructor_id_foreign` FOREIGN KEY (`instructor_id`) REFERENCES `instructors` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `course_includes` ADD CONSTRAINT `course_includes_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE');
        DB::statement('ALTER TABLE `video_progress` ADD CONSTRAINT `video_progress_video_id_foreign` FOREIGN KEY (`video_id`) REFERENCES `videos` (`id`) ON DELETE CASCADE');
    }

    private function dropForeignIfExists(string $table, string $name): void
    {
        $exists = DB::table('information_schema.TABLE_CONSTRAINTS')
            ->where('CONSTRAINT_SCHEMA', DB::getDatabaseName())
            ->where('TABLE_NAME', $table)
            ->where('CONSTRAINT_NAME', $name)
            ->where('CONSTRAINT_TYPE', 'FOREIGN KEY')
            ->exists();

        if ($exists) {
            DB::statement("ALTER TABLE `{$table}` DROP FOREIGN KEY `{$name}`");
        }
    }

    private function dropUniqueForColumnIfExists(string $table, string $column): void
    {
        $indexes = DB::table('information_schema.STATISTICS')
            ->select('INDEX_NAME')
            ->where('TABLE_SCHEMA', DB::getDatabaseName())
            ->where('TABLE_NAME', $table)
            ->where('COLUMN_NAME', $column)
            ->where('NON_UNIQUE', 0)
            ->where('INDEX_NAME', '<>', 'PRIMARY')
            ->distinct()
            ->pluck('INDEX_NAME');

        foreach ($indexes as $index) {
            DB::statement("ALTER TABLE `{$table}` DROP INDEX `{$index}`");
        }
    }
};
