<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Goal karir user — "Become a Web Developer"
        Schema::create('career_goals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('role_saat_ini')->nullable();   // "Multimedia Coordinator"
            $table->string('goal_title');                  // "Become a Web Developer"
            $table->timestamps();
        });

        // Learning plan = kumpulan modul (course) menuju goal
        Schema::create('learning_plan_modules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('career_goal_id')->constrained()->onDelete('cascade');
            $table->string('judul_modul');                 // "Building Blocks of Web Development"
            $table->text('deskripsi')->nullable();
            $table->integer('urutan')->default(0);
            $table->timestamps();
        });

        // Course di dalam tiap modul
        Schema::create('learning_plan_courses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('module_id')->constrained('learning_plan_modules')->onDelete('cascade');
            $table->string('course_id');
            $table->integer('urutan')->default(0);
            $table->timestamps();

            $table->foreign('course_id')->references('id')->on('courses')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('learning_plan_courses');
        Schema::dropIfExists('learning_plan_modules');
        Schema::dropIfExists('career_goals');
    }
};
