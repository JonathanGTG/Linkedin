<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('hands_on_labs', function (Blueprint $table) {
            $table->id();
            $table->string('course_id')->nullable();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->enum('type', ['practice', 'project', 'challenge'])->default('practice');
            $table->enum('level', ['Beginner', 'Intermediate', 'Advanced'])->default('Beginner');
            $table->integer('durasi_menit')->default(30);
            $table->string('teknologi')->nullable();
            $table->boolean('is_published')->default(true);
            $table->timestamps();

            $table->foreign('course_id')->references('id')->on('courses')->onDelete('set null');
        });

        Schema::create('certifications', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('provider');
            $table->string('logo')->nullable();
            $table->enum('type', ['professional_certificate','certification_prep','practice_exam','continuing_education'])->default('professional_certificate');
            $table->integer('jumlah_course')->default(0);
            $table->boolean('is_published')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('certifications');
        Schema::dropIfExists('hands_on_labs');
    }
};
