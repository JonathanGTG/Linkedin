<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        $this->dropIndexIfExists('categories', 'categories_slug_unique');
        $this->dropIndexIfExists('courses', 'courses_slug_unique');
        $this->dropIndexIfExists('skills', 'skills_name_unique');
        $this->dropIndexIfExists('skills', 'skills_slug_unique');
        $this->dropIndexIfExists('instructors', 'instructors_name_slug_unique');

        Schema::table('courses', function (Blueprint $table) {
            if (! Schema::hasColumn('courses', 'durasi')) {
                $table->string('durasi')->nullable()->after('level');
            }
        });

        Schema::table('chapters', function (Blueprint $table) {
            if (! Schema::hasColumn('chapters', 'jumlah_video')) {
                $table->unsignedInteger('jumlah_video')->default(0)->after('judul');
            }
        });

        Schema::table('videos', function (Blueprint $table) {
            if (! Schema::hasColumn('videos', 'durasi')) {
                $table->string('durasi')->nullable()->after('title');
            }
        });

        Schema::table('course_skill', function (Blueprint $table) {
            if (! Schema::hasColumn('course_skill', 'skill_nama')) {
                $table->string('skill_nama')->nullable()->after('skill_id');
            }
        });

        Schema::table('course_instructor', function (Blueprint $table) {
            if (! Schema::hasColumn('course_instructor', 'nama')) {
                $table->string('nama')->nullable()->after('instructor_id');
            }
        });

        $this->addIndexIfMissing('categories', 'categories_slug_index', ['slug']);
        $this->addIndexIfMissing('courses', 'courses_slug_index', ['slug']);
        $this->addIndexIfMissing('skills', 'skills_name_index', ['name']);
        $this->addIndexIfMissing('skills', 'skills_slug_index', ['slug']);
        $this->addIndexIfMissing('instructors', 'instructors_name_index', ['name']);
        $this->addIndexIfMissing('instructors', 'instructors_slug_index', ['slug']);
    }

    public function down(): void
    {
        Schema::table('course_instructor', function (Blueprint $table) {
            if (Schema::hasColumn('course_instructor', 'nama')) {
                $table->dropColumn('nama');
            }
        });

        Schema::table('course_skill', function (Blueprint $table) {
            if (Schema::hasColumn('course_skill', 'skill_nama')) {
                $table->dropColumn('skill_nama');
            }
        });

        Schema::table('videos', function (Blueprint $table) {
            if (Schema::hasColumn('videos', 'durasi')) {
                $table->dropColumn('durasi');
            }
        });

        Schema::table('chapters', function (Blueprint $table) {
            if (Schema::hasColumn('chapters', 'jumlah_video')) {
                $table->dropColumn('jumlah_video');
            }
        });

        Schema::table('courses', function (Blueprint $table) {
            if (Schema::hasColumn('courses', 'durasi')) {
                $table->dropColumn('durasi');
            }
        });
    }

    private function dropIndexIfExists(string $table, string $index): void
    {
        if ($this->indexExists($table, $index)) {
            DB::statement("ALTER TABLE `{$table}` DROP INDEX `{$index}`");
        }
    }

    private function addIndexIfMissing(string $table, string $index, array $columns): void
    {
        if ($this->indexExists($table, $index)) {
            return;
        }

        $columnList = collect($columns)->map(fn ($column) => "`{$column}`")->implode(', ');
        DB::statement("ALTER TABLE `{$table}` ADD INDEX `{$index}` ({$columnList})");
    }

    private function indexExists(string $table, string $index): bool
    {
        return DB::table('information_schema.STATISTICS')
            ->where('TABLE_SCHEMA', DB::getDatabaseName())
            ->where('TABLE_NAME', $table)
            ->where('INDEX_NAME', $index)
            ->exists();
    }
};
